# DSH 新机一键部署包

把当前这台机器的 DSH 使用环境（含插件）复刻到另一台 Windows 电脑。

## 包里有什么

```
install.ps1                        一键安装脚本（装技能 + 可选装工具/插件）
dsh-machine-bootstrap/             技能本体，最终落到 %USERPROFILE%\.dsh\skills\
  SKILL.md                         给 AI 看的完整步骤
  references/recorded-versions.json 本次实测的版本快照
  references/source-machine-notes.md 源机器的操作记录与踩坑
  scripts/install-tools.ps1        便携安装 git / Node+npm / gh（无需管理员）
  scripts/install-plugins.ps1      单独装插件（需 DSH 已退出）
  scripts/verify.ps1               装完自检
README.md                          本文件
```

## 目标机器上怎么用（一键）

1. 把整个 zip 拷到目标电脑并解压，例如 `D:\dsh-bootstrap`。
2. 完全退出 DeepSeek Harness（含托盘图标）。
3. 用 PowerShell 在该目录执行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Tools -Plugins
```

4. 重新打开 DSH：
   - 设置 → 插件：应看到 `dshmarket`、`dsh-cost-meter`
   - 新会话：技能列表应出现 `dsh-machine-bootstrap`

只装技能（不装工具与插件）：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
```

装完工具后需**新开一个终端**，`gh` 还得你本人跑一次 `gh auth login`（会开浏览器）。

## 原理

- DSH 内置的 `@deepseek-ai/dsh-skill-filesystem` 会扫描
  `%USERPROFILE%\.dsh\skills\<名字>\SKILL.md`，并监听目录变化，**新技能无需重启**。
- 插件通过官方 CLI 安装：`dsh plugin --profile desktop add <包名>`，它会
  pnpm 安装并自动把包登记进 `profiles\desktop\package.json` 的
  `dsh.profile.bundles`。
- 本包不依赖管理员权限，也不需要改 DSH 安装目录。

## 上传到云端（供另一台电脑取用）

本机没有 GitHub / npm 登录凭据，最后一步需要你本人操作。三种方式任选：

| 方式 | 步骤 | 另一台怎么拿 |
|---|---|---|
| 网盘 / 微信文件传输 | 直接传 `dsh-machine-bootstrap-skill.zip` | 解压即用 |
| GitHub Release | 新建仓库 → Releases → 上传 zip | 浏览器下载 |
| GitHub 仓库 / Gist | 解压后把 `build` 内容推上去 | `git clone` 后运行 `install.ps1` |

装好 git 与 gh 之后，如果你愿意在本机执行一次 `gh auth login`（会开浏览器），
我可以直接帮你建仓库、发 Release。凭据始终由你掌握。

## 已知限制

- 目标机必须已装 DeepSeek Harness Desktop（本包不改动 DSH 程序本体）。
- 插件安装要求 DSH 完全退出，否则 profile 目录被占用。
- `gh auth login` 必须由用户本人完成，脚本不会代登录。
